package com.aws.sqs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqsPuplisherApplicationTests {

	@Test
	void contextLoads() {
	}

}
